database_name = "kazarmax_db"
schema_name = "turbines"

raw_data_path = "/Workspace/Shared/data/*.json"
cleaned_table_name = 'cleaned'
