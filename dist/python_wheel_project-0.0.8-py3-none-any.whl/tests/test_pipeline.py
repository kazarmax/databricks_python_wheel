import pytest


def test_dummy():
    result = 1

    assert result == 1
