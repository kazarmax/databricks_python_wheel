database_name = "test_databricks"
schema_name = "adzuna"

raw_data_path = "/Workspace/Users/marinakaz.amazon@gmail.com/adzuna_raw_data_20250224_160724.json"
